


(function ($) {
    jQuery.fn.fade = function () {
        $("p.logo2").hide();
        $("p.logo3").hide();
        this.animate({ opacity: 1 }, { queue: false, duration: 800 });
        this.animate({ 'marginTop': 0 + 'px' }, 800, function () {
            $("p.logo2").fadeIn(1500);
        $("p.logo3").fadeIn(2500);
        });
        
    };
})(jQuery);


